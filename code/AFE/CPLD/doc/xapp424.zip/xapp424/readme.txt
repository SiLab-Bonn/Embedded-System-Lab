*************************************************************************
   ____  ____
  /   /\/   /
 /___/  \  /
 \   \   \/    � Copyright 2006-2014 Xilinx, Inc. All rights reserved.
  \   \        This file contains confidential and proprietary
  /   /        information of Xilinx, Inc. and is protected under U.S.
 /___/   /\    and international copyright and other intellectual
 \   \  /  \   property laws.
  \___\/\___\

*************************************************************************

Vendor: Xilinx
Current readme.txt Version: 1.1.2
Date Last Modified:  06JAN2014
Date Created: 12SEP2006

Associated Filename: xapp424.zip
Associated Document: XAPP424, Embedded JTAG ACE Player

Supported Device(s): All FPGA families and CoolRunner-II CPLDs.

*************************************************************************

Disclaimer:

      This disclaimer is not a license and does not grant any rights to
      the materials distributed herewith. Except as otherwise provided in
      a valid license issued to you by Xilinx, and to the maximum extent
      permitted by applicable law: (1) THESE MATERIALS ARE MADE AVAILABLE
      "AS IS" AND WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL
      WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY,
      INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
      NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
      (2) Xilinx shall not be liable (whether in contract or tort,
      including negligence, or under any other theory of liability) for
      any loss or damage of any kind or nature related to, arising under
      or in connection with these materials, including for any direct, or
      any indirect, special, incidental, or consequential loss or damage
      (including loss of data, profits, goodwill, or any type of loss or
      damage suffered as a result of any action brought by a third party)
      even if such damage or loss was reasonably foreseeable or Xilinx
      had been advised of the possibility of the same.

Critical Applications:

      Xilinx products are not designed or intended to be fail-safe, or
      for use in any application requiring fail-safe performance, such as
      life-support or safety devices or systems, Class III medical
      devices, nuclear facilities, applications related to the deployment
      of airbags, or any other applications that could lead to death,
      personal injury, or severe property or environmental damage
      (individually and collectively, "Critical Applications"). Customer
      assumes the sole risk and liability of any use of Xilinx products
      in Critical Applications, subject only to applicable laws and
      regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS
FILE AT ALL TIMES.

*************************************************************************

This readme file contains these sections:

1. REVISION HISTORY
2. OVERVIEW
3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS
4. DESIGN FILE HIERARCHY
5. INSTALLATION AND OPERATING INSTRUCTIONS
6. OTHER INFORMATION (OPTIONAL)
7. SUPPORT


1. REVISION HISTORY

            Readme
Date        Version      Revision Description
=========================================================================
12SEP2006   1.1          Initial Xilinx release.
13DEC2006   1.1.1        Replaced SVF2ACE v1.20 with version 1.21.
06JAN2014   1.1.2        Replaced SVF2ACE v1.21 with version 1.23.
=========================================================================

2. OVERVIEW

This readme describes the files that come with XAPP424.
XAPP424 provides a hardware (VHDL) reference design that can deliver
a sequence of JTAG instructions and data. The JTAG instruction and data
sequence must be provided in the form of a serial vector file (SVF).
The SVF is encoded into the ACE format, described in XAPP424.
The ACE formatted data is delivered in-system to the hardware ACE player
that executes the JTAG instruction and data sequence from the ACE file.

The files include the ACE player reference design in VHDL and
the SVF2ACE translator utility.


3. SOFTWARE TOOLS AND SYSTEM REQUIREMENTS

The reference design requires installation of the Xilinx ISE Design Tools.
The SVF2ACE translation utilities require a Windows PC that can execute
Win32 executables or a Linux PC for executing the linux executable.


4. DESIGN FILE HIERARCHY

  readme.txt                      - This readme.txt file.
  player.vhd                      - Reference ACE player in VHDL. See XAPP424.
  play_bench.vhd                  - Test bench for reference ACE player.
  xapp424_microprogram.xls        - Sheet describing microprogram in player.vhd.
  svf2ace.exe                     - Win32 executable.
  svf2ace_linux                   - Linux executable.

  The spreadsheet xapp424_microcode.xls provides a guide to the
  dataflow of an ACE file through the Player and represents the Program
  Counter (PC) steps corresponding to the CASE statement labeled
  "micro_program".


5. INSTALLATION AND OPERATING INSTRUCTIONS

1) Install the Xilinx ISE Design Tools.
2) Design a board with an FPGA with pins connected to the JTAG interface
   of a target Xilinx FPGA to be configured.
3) Build an FPGA design and integrate the player.vhd module. The design
   must provide a method for feeding an ACE file to the player.vhd module.
   The player.vhd module controls the pins connected to the JTAG interface
   of the target Xiilnx FPGA.
4) Use the Xilinx ISE iMPACT tool to generate SVF for configuring the target
   FPGA with a given bitstream.
5) Use the SVF2ACE utility to encode the generated SVF into an ACE file.
6) Deliver the ACE file to the player.vhd module to deliver the JTAG
   instruction and data sequence to the target FPGA.


6. OTHER INFORMATION

1) Warnings
        ACE does not support Xilinx XC9500, XC9500XL, XC9500XV CPLDs.

2) Design Notes
        The files in this reference design are to be used with XST.

3) Fixes
        SVF2ACE version 1.23 fixes the following problem/bug in SVF2ACE v1.21:
                When the number of hex characters exceeds the number of bits
                specified in SDR/SIR statements with SMASK fields, the incorrect
                bit is masked
                For example:  SDR 34 TDI (0000dbaaa9) SMASK (00ffffffff);
                                has 10 hex characters but the SDR bit count of 34
                                only requires at most 9 hex characters.

4) Known Issues
        None.

7. SUPPORT

To obtain technical support for this reference design, go to
www.xilinx.com/support to locate answers to known issues in the Xilinx
Answers Database or to create a WebCase.

