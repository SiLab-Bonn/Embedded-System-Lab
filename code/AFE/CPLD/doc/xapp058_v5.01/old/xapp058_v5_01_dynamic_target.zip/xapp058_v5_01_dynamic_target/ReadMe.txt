DYNAMIC TARGETING XSVF TO A DEVICE IN AN ARBITRARY JTAG SCAN CHAIN

The xapp058_v4_0.pdf described an advanced option that enabled the 
embedded XSVF player reference code to take an XSVF, that was generated
for a single device, and dynamically retarget the XSVF to the same device
kind within an arbitrary JTAG scan chain.

In general, it is highly recommended that the standard, embedded XSVF
player reference code is used, and that iMPACT build the XSVF file for
the target device in the specific JTAG scan chain.

The xapp058_v4_0.pdf is archived in this zip file along with 
the dynamic targeting version of the reference XSVF player code.
The dynamic targeting code is valid with the base v5.01 embedded
XSVF player reference code and should be reserved for very special
cases that cannot be satisfied by the standard XSVF player and 
where the user has excellent knowledge of the IEEE 1149.1 (JTAG) standard. 



(OBSOLETE) STAND-ALONE XSVF PLAYERS WITH DYNAMIC TARGET CAPABILITIES:

The XAPP058, v4.0 and earlier, download included stand-alone Windows,
command-line executables that "played" an XSVF file to a Xilinx 
Parallel Cable III.

Due to transitions in Xilinx cables and cable drivers, these stand-alone
players have become obsolete.  Copies of the players are kept within this
zip file for archival purposes for those who need to restore the player 
on PCs with older versions of Xilinx ISE software.

