RECOMMENDED PROTOTYPE XSVF EXECUTION (PLAYING):

Xilinx ISE iMPACT 8.2 (or later) software supports execution of 
XSVF files to a Xilinx cable.  Use the latest ISE version available.

Instructions:
1. Start iMPACT
2. Open the iMPACT boundary-scan window
3. Invoke the Add Device function.
4. Select the XSVF file to add to the boundary-scan window
5. Select/highlight the XSVF file in the boundary-scan window.
6. Invoke the Execute XSVF function....iMPACT will execute the XSVF
   through the active JTAG cable.


STAND-ALONE XSVF PLAYERS:

The XAPP058, v4.0 and earlier, download included stand-alone Windows,
command-line executables that "played" an XSVF file to a Xilinx 
Parallel Cable III.

Due to transitions in Xilinx cables and cable drivers, these stand-alone
players have become obsolete.  Copies of the players are kept within this
zip file for archival purposes for those who need to restore the player 
on PCs with older versions of Xilinx ISE software.

