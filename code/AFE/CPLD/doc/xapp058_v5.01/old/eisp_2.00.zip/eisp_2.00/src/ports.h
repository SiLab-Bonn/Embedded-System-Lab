/*******************************************************/
/* file: ports.h                                       */
/* abstract:  This file contains extern declarations   */
/*            for providing stimulus to the JTAG ports.*/
/*******************************************************/

#ifndef ports_dot_h
#define ports_dot_h

#if 0
#define DEBUG_MODE  /* this line and output the                   */
		    /* TMS and TDI values on the rising edge of                   */
		    /* the clock                                                  */
#endif


#ifdef WIN95PP
#define DATA_OFFSET    (unsigned short) 0
#define STATUS_OFFSET  (unsigned short) 1
#define CONTROL_OFFSET (unsigned short) 2

typedef union outPortUnion {
	unsigned char value;
	struct opBitsStr {
		unsigned char tdi:1;
		unsigned char tck:1;
		unsigned char tms:1;
		unsigned char zero:1;
		unsigned char one:1;
		unsigned char bit5:1;
		unsigned char bit6:1;
		unsigned char bit7:1;
	} bits;
} outPortType;

typedef union inPortUnion {
	unsigned char value;
	struct ipBitsStr {
		unsigned char bit0:1;
		unsigned char bit1:1;
		unsigned char bit2:1;
		unsigned char bit3:1;
		unsigned char tdo:1;
		unsigned char bit5:1;
		unsigned char bit6:1;
		unsigned char bit7:1;
	} bits;
} inPortType;
#endif

/* these constants are used to send the appropriate ports to setPort */
/* they should be enumerated types, but some of the microcontroller  */
/* compilers don't like enumerated types */
#define TCK (short) 0
#define TMS (short) 1
#define TDI (short) 2

/* set the port "p" (TCK, TMS, or TDI) to val (0 or 1) */
extern void setPort(short p, short val);

/* read the TDO bit and store it in val */
extern unsigned char readTDOBit();

/* make clock go down->up->down*/
extern void pulseClock();

/* read the next byte of data from the xsvf file */
extern void readByte(unsigned char *data);

extern void waitTime(long microsec);

#endif
