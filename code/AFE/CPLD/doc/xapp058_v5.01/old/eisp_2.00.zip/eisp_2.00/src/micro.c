/*************************************************************/
/* file: micro.c                                             */
/* abstract:  This file contains the main function           */
/*            call for reading in a file from a prom         */
/*            and pumping the JTAG ports.                    */
/*                                                           */
/* Notes: There is a compiler switch called DEBUG_MODE.      */
/*        If DEBUG_MODE is defined, the compiler will read   */
/*        the xsvf file from a file called "prom.bit".      */
/*        It will also enable debugging of the code          */
/*        by printing the TDI and TMS values on the          */
/*        rising edge of TCLK.                               */
/*************************************************************/

#include "lenval.h"
#include "ports.h"
/*#include "prgispx.h"*/

/* encodings of xsvf instructions */

#define XCOMPLETE        0 
#define XTDOMASK         1 
#define XSIR             2 
#define XSDR             3 
#define XRUNTEST         4        
#define XREPEAT          7
#define XSDRSIZE         8
#define XSDRTDO          9
#define XSETSDRMASKS     10
#define XSDRINC          11
#define XSDRB            12
#define XSDRC            13
#define XSDRE            14
#define XSDRTDOB         15
#define XSDRTDOC         16
#define XSDRTDOE         17

/* return number of bytes necessary for "num" bits */
#define BYTES(num) \
        (short) (((num%8)==0) ? (num/8) : (num/8+1))

extern void doSDRMasking(lenVal *dataVal, lenVal *nextData, 
			 lenVal *addressMask, lenVal *dataMask);
extern short loadSDR(int numBits, lenVal *dataVal, lenVal *TDOExpected, lenVal *TDOMask);
extern short loadSDRTDOB(int numBits, lenVal *dataVal, lenVal *TDOExpected, lenVal *TDOMask);
extern void loadSDRbegin(int numBits, lenVal *dataVal);
extern void loadSDRhold(int numBits, lenVal *dataVal);
extern void loadSDRend(int numBits, lenVal *dataVal);
extern void clockOutLenVal(lenVal *lv,long numBits,lenVal *tdoStore);
extern void shiftOutLenVal(lenVal *lv,long numBits, short last);
extern void shiftOutLenValStoreTDO(lenVal *lv,long numBits,lenVal *tdoStore,int last);
extern void gotoIdle();
short checkAgainstTDO(lenVal *actualTDO,lenVal *TDOExpected,long *runTestTime,int *failTimes);
lenVal TDOMask;    /* last TDOMask received */
lenVal maxRepeat;  /* max times tdo can fail before ISP considered failed */
lenVal runTestTimes; /* value of last XRUNTEST instruction */

/*extern BYTE *xsvf_data;*/

#include <stdio.h>
#ifdef DEBUG_MODE
FILE *in;          /* for debugging */
#endif

void stoi_new(lenVal * x, short Bytes)
{
 int num = 0;
 int i =0;
//  while (x->val[i]!='\0')
 //   {
//      if( (x->val[i] >= '0') && (x->val[i] <= '9'))
 //       {
 //     num = num*16 + x->val[i]-'0';
 //       }
 //     else if((x->val[i] >= 'a')&& (x->val[i] <= 'f'))
 //       {
 //         num = num*16 + x->val[i] - 'a' + 10;
 //       }
for(i=0;i<Bytes;i++)
	{
	if (x->val[i] < 16)
	   printf("0");
	printf("%x",x->val[i]);

    }
	printf("\n");
   // return( num);
}
/* clock out the bit onto a particular port */
void clockOutBit(short p, short val)
{
	setPort(p,val);  /* change the value of TMS or TDI */
	pulseClock();    /* set TCK to Low->High->Low      */
}

/* clock out numBits from a lenVal;  the least significant bits are */
/* output on the TDI line first; exit into the exit(DR/IR) state.   */ 
/* if tdoStore!=0, store the TDO bits clocked out into tdoStore.    */
void clockOutLenVal(lenVal *lv,long numBits,lenVal *tdoStore)
{
	int i;
	short j,k;
   
	/* if tdoStore is not null set it up to store the tdoValue */
	if (tdoStore)
		tdoStore->len=lv->len;
    
	for (i=0;i<lv->len;i++)
	{
		/* nextByte contains the next byte of lenVal to be shifted out */ 
		/* into the TDI port                                           */
		unsigned char nextByte=lv->val[lv->len-i-1]; 
		unsigned char nextReadByte=0;
		unsigned char tdoBit;
		
		/* on the last bit, set TMS to 1 so that we go to the EXIT DR */
		/* or to the EXIT IR state */
		for (j=0;j<8;j++)
		{
			/* send in 1 byte at a time */
			/* on last bit, exit SHIFT SDR */
			if (numBits==1)
				setPort(TMS,1);  
	    
			if (numBits>0)
			{
				tdoBit=readTDOBit();  /* read the TDO port into tdoBit */
				clockOutBit(TDI,(short)(nextByte & 0x1));  /* set TDI to last bit */
				nextByte=nextByte>>1;
				numBits--;
				/* first tdoBit of the byte goes to 0x00000001   */
				/* second tdoBit goes to 0x00000010, etc.        */
				/* Shift the TDO bit to the right location below */
				for (k=0;k<j;k++)
					tdoBit=tdoBit<<1; 
		
				/* store the TDO value in the nextReadByte */
				nextReadByte|=tdoBit;
			}
		}
		
		/* if storing the TDO value, store it in the correct place */
		if (tdoStore) {
			tdoStore->val[tdoStore->len-i-1]=nextReadByte;
#ifdef DEBUG_MODE
			printf("byte %x : index %x\n", nextReadByte, tdoStore->len-i-1);
#endif
		}
	}
}

/* clock out numBits from a lenVal;  the least significant bits are */
/* output on the TDI line first; stay in the current state          */
void shiftOutLenVal(lenVal *lv,long numBits,short last)
{
	int i;
	short j;
	
    	  
	for (i=0;i<lv->len;i++)
	{
		/* nextByte contains the next byte of lenVal to be shifted out */ 
		/* into the TDI port                                           */
		unsigned char nextByte=lv->val[lv->len-i-1]; 
		
		for (j=0;j<8;j++)
		{
			/* send in 1 byte at a time */
			/* on last bit, exit SHIFT SDR */
			if ((last ==1) && (numBits==1))
				setPort(TMS,1);  

	    
			if (numBits>0)
			{
				clockOutBit(TDI,(short) (nextByte & 0x1));  /* set TDI to last bit */
				nextByte=nextByte>>1;
				numBits--;
			}
		}
			       
}
}
void shiftOutLenValStoreTDO(lenVal *lv,long numBits,lenVal *tdoStore,int last)
{
	int i;
	short j,k;
	
    	/* if tdoStore is not null set it up to store the tdoValue */
	if (tdoStore)
	  {

	    tdoStore->len=lv->len;
	  }
	for (i=0;i<lv->len;i++)
	{
		/* nextByte contains the next byte of lenVal to be shifted out */ 
		/* into the TDI port                                           */
		unsigned char nextByte=lv->val[lv->len-i-1]; 
		unsigned char nextReadByte=0;
		unsigned char tdoBit;
		for (j=0;j<8;j++)
		{
		       
      			/* send in 1 byte at a time */
			/* on last bit, exit SHIFT SDR */
			if ((last ==1) && (numBits==1))
				setPort(TMS,1);  
			if (numBits>0)
			{
				clockOutBit(TDI,(short) (nextByte & 0x1));  /* set TDI to last bit */
				nextByte=nextByte>>1;
				numBits--;
				/* first tdoBit of the byte goes to 0x00000001   */
				/* second tdoBit goes to 0x00000010, etc.        */
				/* Shift the TDO bit to the right location below */
				for (k=0;k<j;k++)
					tdoBit=tdoBit<<1; 
		
				/* store the TDO value in the nextReadByte */
				nextReadByte|=tdoBit;
			}
		}
		/* if storing the TDO value, store it in the correct place */
		if (tdoStore) {
			tdoStore->val[tdoStore->len-i-1]=nextReadByte;
#ifdef DEBUG_MODE
			printf("byte %x : index %x\n", nextReadByte, tdoStore->len-i-1);
#endif
		}	
	}
}

/* parse the xsvf file and pump the bits */
int main()
{ 
	lenVal inst; /* instruction */
	lenVal bitLengths; /* hold the length of the arguments to read in */
	lenVal dataVal,TDOExpected;
	lenVal SDRSize,addressMask,dataMask;
	lenVal sdrInstructs;
	long i;
    
#ifdef DEBUG_MODE
	/* read from the file "prom.bit" instead of a real prom */
	in=fopen("prom.bit","rb");
#endif

	gotoIdle();
	while (1)
	{
		/*lenVal dataVal,TDOExpected;*/
		readVal(&inst,1);  /* read 1 byte for the instruction */
		
		/*if((long)xsvf_data==0x2048e0)
			while(1);*/
			
		switch (value(&inst))  
		{
			case XTDOMASK:
				/* readin new TDOMask */
				readVal(&TDOMask,BYTES(value(&SDRSize)));  
				#ifdef DEBUG_MODE1
				printf("TDOMASK");
				stoi_new(&TDOMask,BYTES(value(&SDRSize)));
				#endif
				break;
				
			case XREPEAT:
				/* read in the new XREPEAT value */
				readVal(&maxRepeat,1);
				#ifdef DEBUG_MODE1
				printf("maxRepeat: %x\n",value(&maxRepeat));
				#endif
				break;
				
			case XRUNTEST:
				/* read in the new RUNTEST value */
				readVal(&runTestTimes,4);
				#ifdef DEBUG_MODE1
				printf("runTestTimes: %x\n",value(&runTestTimes));
				#endif
				break;
				
			case XSIR:
				#ifdef DEBUG_MODE1
                                printf("XSIR: \n");
                                #endif
				/* load a value into the instruction register */
				clockOutBit(TMS,1);  /* Select-DR-Scan state  */
				clockOutBit(TMS,1);  /* Select-IR-Scan state  */
				clockOutBit(TMS,0);  /* Capture-IR state      */
				clockOutBit(TMS,0);  /* Shift-IR state        */
				readVal(&bitLengths,1); /* get number of bits to shift in */
				#ifdef DEBUG_MODE1
				printf("XSIR----bitLengths: %x\n",value(&bitLengths));
				#endif
				/* store instruction to shift in */
				readVal(&dataVal,BYTES(value(&bitLengths))); 
				#ifdef DEBUG_MODE1
				printf("XSIR----dataVal:");
				 stoi_new(&dataVal,BYTES(value(&bitLengths)));
				#endif
				/* send the instruction through the TDI port and end up   */
				/* dumped in the Exit-IR state                            */
				clockOutLenVal(&dataVal,value(&bitLengths),0);
				clockOutBit(TMS,1);  /* Update-IR state       */
				clockOutBit(TMS,0);  /* Run-Test/Idle state   */
				break;
				
			case XSDRTDO:
				/* get the data value to be shifted in */
				readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDO-----dataVal:");
				 stoi_new(&dataVal,BYTES(value(&SDRSize)));
				printf("BYTES ----- %d\n",BYTES(value(&SDRSize)));
				#endif
				/* store the TDOExpected value    */
				readVal(&TDOExpected,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDO-----TDOExpected:");
				stoi_new(&TDOExpected,BYTES(value(&SDRSize)));
				printf("BYTES ----- %d\n",BYTES(value(&SDRSize)));
				#endif
				/* shift in the data value and verify the TDO value against */
				/* the expected value                                       */
				if (!loadSDR(value(&SDRSize), &dataVal, &TDOExpected, &TDOMask))
				{
					/* The ISP operation TDOs failed to match expected */
					printf("******************************Did not Match*******************\n");
					return 0;  
				}
				break; 
	 
                       case XSDRTDOB:
                                /* get the data value to be shifted in */
                                readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDOB-----dataVal:");
				stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
                                /* store the TDOExpected value    */
                                readVal(&TDOExpected,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDOB-----TDOExpected:");
				stoi_new(&TDOExpected,BYTES(value(&SDRSize)));
				#endif
                                /* shift in the data value and verify the TDO value against */
                                /* the expected value                                       */
                                if (!loadSDRTDOB(value(&SDRSize), &dataVal, &TDOExpected, &TDOMask))
                                  {
                                    /* The ISP operation TDOs failed to match expected */
					printf("******************************Did not Match*******************\n");
                                        return 0;
                                  }
                                break;
                                 
                       case XSDRTDOC:
                                /* get the data value to be shifted in */
                                readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDOC-----dataVal:");
				stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
                                /* store the TDOExpected value    */
                                readVal(&TDOExpected,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDOC-----TDOExpected:");
				 stoi_new(&TDOExpected,BYTES(value(&SDRSize)));
				#endif
                                /* shift in the data value and verify the TDO value against */
                                /* the expected value                                       */
                                if (!loadSDRTDOB(value(&SDRSize), &dataVal, &TDOExpected, &TDOMask))
                                  {
                                    /* The ISP operation TDOs failed to match expected */
					printf("******************************Did not Match*******************\n");
                                        return 0;
                                  }
                                break;
 
                     case XSDRTDOE:
                                /* get the data value to be shifted in */
                                readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDOE-----dataVal:");
				stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
                                /* store the TDOExpected value    */
                                readVal(&TDOExpected,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRTDOE-----TDOExpected:");
				stoi_new(&TDOExpected,BYTES(value(&SDRSize)));
				#endif
                                /* shift in the data value and verify the TDO value against */
                                /* the expected value                                       */
                                if (!loadSDRTDOB(value(&SDRSize), &dataVal, &TDOExpected, &TDOMask))
                                  {
                                    /* The ISP operation TDOs failed to match expected */
					printf("******************************Did not Match*******************\n");
                                        return 0;
                                  }
                                break;

			case XSDR:    
				readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDR-----dataVal:");
				stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
				/* use TDOExpected from last XSDRTDO instruction */
				if (!loadSDR(value(&SDRSize), &dataVal, &TDOExpected, &TDOMask))
				   {
					printf("******************************Did not Match*******************\n");
					return 0;  /* TDOs failed to match expected */
				   }
				break;
				
			case XSDRB:    
				readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRB-----dataVal:");
				stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
				loadSDRbegin(value(&SDRSize), &dataVal);
				break;

			case XSDRC:    
				readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRC-----dataVal:");
				stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
				loadSDRhold(value(&SDRSize), &dataVal);
				break;

			case XSDRE:    
				readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRE-----dataVal:");
			 	stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
				loadSDRend(value(&SDRSize), &dataVal);
				break;

			case XSDRINC:
				readVal(&dataVal,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSDRINC-----dataVal:");
				stoi_new(&dataVal,BYTES(value(&SDRSize)));
				#endif
				if (!loadSDR(value(&SDRSize), &dataVal, &TDOExpected, &TDOMask)){
					printf("******************************Did not Match*******************\n");
					return 0;  /* TDOs failed to match expected */
					}
				readVal(&sdrInstructs,1);
				#ifdef DEBUG_MODE1
				printf("XSDRINC-----sdrInstructs:");
			 	stoi_new(&sdrInstructs,1);
				#endif
				for (i=0;i<value(&sdrInstructs);i++)
				{
					lenVal nextData;
					int dataLength=8; /* fix to be number of 1's in dataMask */
					readVal(&nextData,BYTES(dataLength));
					#ifdef DEBUG_MODE1
					printf("XSDRINC-----nextData:");
					 stoi_new(&nextData,BYTES(dataLength));
					#endif
					doSDRMasking(&dataVal, &nextData, &addressMask, &dataMask);
					if (!loadSDR(value(&SDRSize), &dataVal, &TDOExpected, &TDOMask)){
					printf("******************************Did not Match*******************\n");
						return 0;  /* TDOs failed to match expected */
					}
				}
				break;
				
			case XSETSDRMASKS:
				/* read the addressMask */
				readVal(&addressMask,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSETSDRMASKS-----addressMask:");
				stoi_new(&addressMask,BYTES(value(&SDRSize)));
				#endif
				/* read the dataMask    */
				readVal(&dataMask,BYTES(value(&SDRSize)));
				#ifdef DEBUG_MODE1
				printf("XSETSDRMASKS-----dataMask:");
				stoi_new(&dataMask,BYTES(value(&SDRSize)));
				#endif
				break;
				
			case XCOMPLETE:
				/* return from subroutine */
				#ifdef DEBUG_MODE1
				printf("XCOMPLETE: \n");
				#endif
				return 1;
				break;   
        
			case XSDRSIZE:
				/* set the SDRSize value */
				readVal(&SDRSize,4);
				#ifdef DEBUG_MODE1
				printf("SDRSize: %x\n",value(&SDRSize));
				#endif
				break;
	    
			default:
				printf("Unknown Instruction encountered\n");
				printf("Make sure you have used the right options to convert svf2xsvf\n");
				printf("For FPGAs use -fpga option with the -rlen option to specify the record length\n");
		}
	}
}



/* determine the next data value from the XSDRINC instruction and store     */
/* it in dataVal.                                                           */
/* Example:  dataVal=0x01ff, nextData=0xab, addressMask=0x0100,             */
/*           dataMask=0x00ff, should set dataVal to 0x02ab                  */
void doSDRMasking(lenVal *dataVal, lenVal *nextData, lenVal *addressMask,
		  lenVal *dataMask)
{
	int i,j,count=0;
	
	/* add the address Mask to dataVal and return as a new dataVal */
	addVal(dataVal, dataVal, addressMask);  
	for (i=0;i<dataMask->len;i++)
	{
		/* look through each bit of the dataMask. If the bit is    */
		/* 1, then it is data and we must replace the corresponding*/
		/* bit of dataVal with the appropriate bit of nextData     */
		for (j=0;j<8;j++)
			if (RetBit(dataMask,i,j))  /* this bit is data */
			{
				/* replace the bit of dataVal with a bit from nextData */
				SetBit(dataVal,i,j,RetBit(nextData,count/8,count%8));
				count++;  /* count how many bits have been replaced */
			}
	}
}

/* goto the idle state by setting TMS to 1 for 5 clocks, followed by TMS */
/* equal to 0 */
void gotoIdle()
{
	int i;
	setPort(TMS,1);
	for (i=0;i<5;i++)
		pulseClock();
	setPort(TMS,0);
	pulseClock();
}
    

/* return 0 iff the TDO doesn't match what is expected */
short loadSDR(int numBits, lenVal *dataVal, lenVal *TDOExpected, 
	      lenVal *TDOMask)
{
	int failTimes=0;
	long runTestTime;
	lenVal actualTDO;

	actualTDO.len = dataVal->len;

	/* store local copy of wait time */
	runTestTime = value(&runTestTimes);

	/* data processing loop */
	while (1)
	{
		clockOutBit(TMS,1);  /* Select-DR-Scan state  */
		clockOutBit(TMS,0);  /* Capture-DR state      */
		clockOutBit(TMS,0);  /* Shift-DR state        */
		/* output dataVal onto the TDI ports; store the TDO value returned */
		clockOutLenVal(dataVal,numBits,&actualTDO);
		if (TDOExpected != (lenVal *) 0x0) {
			/* compare the TDO value against the expected TDO value */
			if (EqualLenVal(TDOExpected,&actualTDO,TDOMask))
			{
				/* TDO matched what was expected */
				clockOutBit(TMS,1);  /* Update-DR state    */
				clockOutBit(TMS,0);  /* Run-Test/Idle state*/

				/* wait in Run-Test/Idle state */
				waitTime(runTestTime);
				break;
			} else {
				/* TDO did not match the value expected */
				failTimes++;      /* update failure count */
				if (failTimes>value(&maxRepeat))
					return 0;				/* ISP failed */
			
				clockOutBit(TMS,0); /* Pause-DR state      */
				clockOutBit(TMS,1); /* Exit2-DR state      */
				clockOutBit(TMS,0); /* Shift-DR state      */
				clockOutBit(TMS,1); /* Exit1-DR state      */
				clockOutBit(TMS,1); /* Update-DR state     */
				clockOutBit(TMS,0); /* Run-Test/Idle state */
				/* wait in Run-Test/Idle state */
				waitTime(runTestTime);
				/* as a paranoia check, increase wait time by 25% */
				runTestTime += (runTestTime>>2);
			}
		} else {

			/* No TDO check - go to RTI */
			
			clockOutBit(TMS,1);  /* Update-DR state    */
			clockOutBit(TMS,0);  /* Run-Test/Idle state*/

			/* wait in Run-Test/Idle state */
			
			waitTime(runTestTime);
			break;
		}
	}
	return 1;  
}

short loadSDRTDOB(int numBits, lenVal *dataVal, lenVal *TDOExpected, 
	      lenVal *TDOMask)
{
	int failTimes=0;
	long runTestTime;
	lenVal actualTDO;
	short retValue;

	actualTDO.len = dataVal->len;

	/* store local copy of wait time */
	runTestTime = value(&runTestTimes);

	/* data processing loop */
	while (1)
	{
		clockOutBit(TMS,1);  /* Select-DR-Scan state  */
		clockOutBit(TMS,0);  /* Capture-DR state      */
		clockOutBit(TMS,0);  /* Shift-DR state        */
		/* output dataVal onto the TDI ports; store the TDO value returned */
		 shiftOutLenValStoreTDO(dataVal,numBits,&actualTDO,0);
		if (TDOExpected != (lenVal *) 0x0) {
		  /* compare the TDO value against the expected TDO value */
		  if(retValue =checkAgainstTDO(&actualTDO,TDOExpected,&runTestTime,&failTimes)==1)
		    break;
		  else if(retValue == 0)
		    return 0;
		 
		   
		}
                /*else {*/

		 /* No TDO check - go to RTI */
			
		/*clockOutBit(TMS,1); */ /* Update-DR state    */
		/*	clockOutBit(TMS,0);  *//* Run-Test/Idle state*/

			/* wait in Run-Test/Idle state */
			
		/*	waitTime(runTestTime);
			break;*/
		/*	}*/
	}
	return 1;  
}

short loadSDRTDOC(int numBits, lenVal *dataVal, lenVal *TDOExpected, 
	      lenVal *TDOMask)
{
	int failTimes=0;
	long runTestTime;
	lenVal actualTDO;
	short retValue;

	actualTDO.len = dataVal->len;

	/* store local copy of wait time */
	runTestTime = value(&runTestTimes);

	/* data processing loop */
	while (1)
	{
		/* output dataVal onto the TDI ports; store the TDO value returned */
		 shiftOutLenValStoreTDO(dataVal,numBits,&actualTDO,0);
		if (TDOExpected != (lenVal *) 0x0) {
		  /* compare the TDO value against the expected TDO value */
		  if(retValue =checkAgainstTDO(&actualTDO,TDOExpected,&runTestTime,&failTimes)==1)
		    break;
		  else if(retValue == 0)
		    return 0;
		 
		   
		}
                /*else {*/

		 /* No TDO check - go to RTI */
			
		/*clockOutBit(TMS,1); */ /* Update-DR state    */
		/*	clockOutBit(TMS,0);  *//* Run-Test/Idle state*/

			/* wait in Run-Test/Idle state */
			
		/*	waitTime(runTestTime);
			break;*/
		/*	}*/
	}
	return 1;  
}


short loadSDRTDOE(int numBits, lenVal *dataVal, lenVal *TDOExpected, 
	      lenVal *TDOMask)
{
	int failTimes=0;
	long runTestTime;
	lenVal actualTDO;
	short retValue;

	actualTDO.len = dataVal->len;

	/* store local copy of wait time */
	runTestTime = value(&runTestTimes);

	/* data processing loop */
	while (1)
	{
		
		/* output dataVal onto the TDI ports; store the TDO value returned */
		 shiftOutLenValStoreTDO(dataVal,numBits,&actualTDO,1);
		if (TDOExpected != (lenVal *) 0x0) {
		  /* compare the TDO value against the expected TDO value */
		  if(retValue =checkAgainstTDO(&actualTDO,TDOExpected,&runTestTime,&failTimes)==1)
		    {			
		      /* TDO matched what was expected */
		      clockOutBit(TMS,1);  /* Update-DR state    */
		      clockOutBit(TMS,0);  /* Run-Test/Idle state*/

		      /* wait in Run-Test/Idle state */
		      waitTime(runTestTime);
		      break;
		      
		    }
		  else if(retValue == 0)
		    return 0;
		 
		   
		}
                /*else {*/

		 /* No TDO check - go to RTI */
			
		/*clockOutBit(TMS,1); */ /* Update-DR state    */
		/*	clockOutBit(TMS,0);  *//* Run-Test/Idle state*/

			/* wait in Run-Test/Idle state */
			
		/*	waitTime(runTestTime);
			break;*/
		/*	}*/
	}
	return 1;  
}
short checkAgainstTDO(lenVal *actualTDO,lenVal *TDOExpected,long *runTestTime,int *failTimes)
	  {
		  if (EqualLenVal(TDOExpected,actualTDO,&TDOMask))
			{
				/* TDO matched what was expected */
				/*clockOutBit(TMS,1); */ /* Update-DR state    */
				/*clockOutBit(TMS,0); */ /* Run-Test/Idle state*/

				/* wait in Run-Test/Idle state */
				/*waitTime(*runTestTime);*/
				return 1;
				
			} else {
				/* TDO did not match the value expected */
				/**failTimes++;*/      /* update failure count */
				/*if (*failTimes>value(&maxRepeat))*/
					return 0;				/* ISP failed */
			
				/*clockOutBit(TMS,0); *//* Pause-DR state      */
				/*clockOutBit(TMS,1); *//* Exit2-DR state      */
				/*clockOutBit(TMS,0); *//* Shift-DR state      */
				/*clockOutBit(TMS,1); *//* Exit1-DR state      */
				/*clockOutBit(TMS,1); *//* Update-DR state     */
				/*clockOutBit(TMS,0); *//* Run-Test/Idle state */
				/* wait in Run-Test/Idle state */
				/*waitTime(*runTestTime);
				/* as a paranoia check, increase wait time by 25% */
				/**runTestTime += (*runTestTime>>2);*/
				/*return 2;*/
			}
		  
	  }	
void loadSDRbegin(int numBits, lenVal *dataVal)
{

	clockOutBit(TMS,1);  /* Select-DR-Scan state  */
	clockOutBit(TMS,0);  /* Capture-DR state      */
	clockOutBit(TMS,0);  /* Shift-DR state        */
	/* output dataVal onto the TDI ports; store the TDO value returned */
	shiftOutLenVal(dataVal,numBits,0);
}

void loadSDRend(int numBits, lenVal *dataVal)
{

	/* output dataVal onto the TDI ports; store the TDO value returned */
	shiftOutLenVal(dataVal,numBits,1);
	clockOutBit(TMS,1);  /* Update-DR state    */
	clockOutBit(TMS,0);  /* Run-Test/Idle state*/
}


void loadSDRhold(int numBits, lenVal *dataVal)
{

	/* output dataVal onto the TDI ports; store the TDO value returned */
	shiftOutLenVal(dataVal,numBits,0);
}







