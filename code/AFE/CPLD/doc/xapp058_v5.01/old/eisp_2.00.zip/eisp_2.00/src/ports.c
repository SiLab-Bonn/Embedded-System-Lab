/*******************************************************/
/* file: ports.c                                       */
/* abstract:  This file contains the routines to       */
/*            output values on the JTAG ports, to read */
/*            the TDO bit, and to read a byte of data  */
/*            from the prom                            */
/*                                                     */
/* Notes: See the notes for micro.c for explanation of */
/*        the compiler switch  "DEBUG_MODE".           */
/*******************************************************/
#include "ports.h"
/*#include "prgispx.h"*/

#ifdef DEBUG_MODE
#include "stdio.h"
extern FILE *in;
#endif

#ifdef DEBUG_MODE
/* if in debugging mode, use variables instead of setting the ports */
short pTCK,pTMS,pTDI;
#endif

#ifdef WIN95PP
#include "conio.h"
static inPortType in_word;
static outPortType out_word;
static unsigned short base_port = 0x378;
static int once = 0;
#endif


/*BYTE *xsvf_data=0;*/


/* if in debugging mode, then just set the variables */
void setPort(short p,short val)
{
#ifdef DEBUG_MODE
	if (p==TCK)
		pTCK=val;
	if (p==TMS)
		pTMS=val;
	if (p==TDI)
		pTDI=val;
#endif

#ifdef WIN95PP
	if (once == 0) {
		out_word.bits.one = 1;
		out_word.bits.zero = 0;
		once = 1;
	}
	if (p==TMS)
		out_word.bits.tms = (unsigned char) val;
	if (p==TDI)
		out_word.bits.tdi = (unsigned char) val;
	if (p==TCK) {
		out_word.bits.tck = (unsigned char) val;
		(void) _outp( (unsigned short) (base_port + 0), out_word.value );
	}
	/*#else*/
	/* me40 specific code to control isp bits */
	/*	switch(p)
	{
		case TCK:
			if(val)
				*(BYTE*)(void*)PORTE0|=ISP_TCK;
			else
				*(BYTE*)(void*)PORTE0&=~(ISP_TCK);
			break;
			
		case TMS:
			if(val)
				*(BYTE*)(void*)PORTE0|=ISP_TMS;
			else
				*(BYTE*)(void*)PORTE0&=~(ISP_TMS);
			break;
			
		case TDI:
			if(val)
				*(BYTE*)(void*)PORTE0|=ISP_TDI;
			else
				*(BYTE*)(void*)PORTE0&=~(ISP_TDI);
			break;
			
		default:
			break;
	}*/
	
#endif
}


#ifdef DEBUG_MODE
void printPorts()
{
	printf("M=%d  I=%d\n",pTMS,pTDI);
}
#endif


/* toggle tck LHL */
void pulseClock()
{
	setPort(TCK,0);  /* set the TCK port to low  */
	setPort(TCK,1);  /* set the TCK port to high */
#ifdef DEBUG_MODE
	/* if in debugging mode, print the ports on the rising clock edge */
	printPorts();
#endif
	setPort(TCK,0);  /* set the TCK port to low  */
}


/* read in a byte of data from the prom */
void readByte(unsigned char *data)
{
#ifdef DEBUG_MODE
	/* pretend reading using a file */
	fscanf(in,"%c",data);
#endif
	/**data=*xsvf_data++;*/
}

/* read the TDO bit from port */
unsigned char readTDOBit()
{
#ifdef DEBUG_MODE
	static int i = 0;
	if (i++ < 6)
		return 0;
	else {
		i = 0;
		return 1;  /* garbage value for now; replace with real port read. */
	}
#endif

#ifdef WIN95PP
	in_word.value = (unsigned char) _inp( (unsigned short) (base_port + STATUS_OFFSET) );
	if (in_word.bits.tdo == 0x1) {
		return( (unsigned char) 1 );
	}
	return( (unsigned char) 0 );

	/*#else
	
	if(*(BYTE*)(void*)PORTE0&ISP_TDO)
		return(1);
	return(0);
	*/	
#endif
}


/* Wait at least the specified number of microsec.                           */
/* Use a timer if possible; otherwise estimate the number of instructions    */
/* necessary to be run based on the microcontroller speed.  For this example */
/* we pulse the TCK port a number of times based on the processor speed.     */
void waitTime(long microsec)
{
	long repeat;

#define CLOCK_RATE 150 /* set to be the clock rate of the system in kHz */
	long clockRunTests=microsec*CLOCK_RATE/1000;
#ifndef DEBUG_MODE
	for (repeat=0;repeat<clockRunTests;repeat++)
		pulseClock();
#endif
}
